window = global;
delete global;
delete Buffer;

yuan = {}
window.__ZH__ = {
    "zse": {
        "zk": [
            1170614578,
            1024848638,
            1413669199,
            -343334464,
            -766094290,
            -1373058082,
            -143119608,
            -297228157,
            1933479194,
            -971186181,
            -406453910,
            460404854,
            -547427574,
            -1891326262,
            -1679095901,
            2119585428,
            -2029270069,
            2035090028,
            -1521520070,
            -5587175,
            -77751101,
            -2094365853,
            -1243052806,
            1579901135,
            1321810770,
            456816404,
            -1391643889,
            -229302305,
            330002838,
            -788960546,
            363569021,
            -1947871109
        ],
        "zb": [
            20,
            223,
            245,
            7,
            248,
            2,
            194,
            209,
            87,
            6,
            227,
            253,
            240,
            128,
            222,
            91,
            237,
            9,
            125,
            157,
            230,
            93,
            252,
            205,
            90,
            79,
            144,
            199,
            159,
            197,
            186,
            167,
            39,
            37,
            156,
            198,
            38,
            42,
            43,
            168,
            217,
            153,
            15,
            103,
            80,
            189,
            71,
            191,
            97,
            84,
            247,
            95,
            36,
            69,
            14,
            35,
            12,
            171,
            28,
            114,
            178,
            148,
            86,
            182,
            32,
            83,
            158,
            109,
            22,
            255,
            94,
            238,
            151,
            85,
            77,
            124,
            254,
            18,
            4,
            26,
            123,
            176,
            232,
            193,
            131,
            172,
            143,
            142,
            150,
            30,
            10,
            146,
            162,
            62,
            224,
            218,
            196,
            229,
            1,
            192,
            213,
            27,
            110,
            56,
            231,
            180,
            138,
            107,
            242,
            187,
            54,
            120,
            19,
            44,
            117,
            228,
            215,
            203,
            53,
            239,
            251,
            127,
            81,
            11,
            133,
            96,
            204,
            132,
            41,
            115,
            73,
            55,
            249,
            147,
            102,
            48,
            122,
            145,
            106,
            118,
            74,
            190,
            29,
            16,
            174,
            5,
            177,
            129,
            63,
            113,
            99,
            31,
            161,
            76,
            246,
            34,
            211,
            13,
            60,
            68,
            207,
            160,
            65,
            111,
            82,
            165,
            67,
            169,
            225,
            57,
            112,
            244,
            155,
            51,
            236,
            200,
            233,
            58,
            61,
            47,
            100,
            137,
            185,
            64,
            17,
            70,
            234,
            163,
            219,
            108,
            170,
            166,
            59,
            149,
            52,
            105,
            24,
            212,
            78,
            173,
            45,
            0,
            116,
            226,
            119,
            136,
            206,
            135,
            175,
            195,
            25,
            92,
            121,
            208,
            126,
            139,
            3,
            75,
            141,
            21,
            130,
            98,
            241,
            40,
            154,
            66,
            184,
            49,
            181,
            46,
            243,
            88,
            101,
            183,
            8,
            23,
            72,
            188,
            104,
            179,
            210,
            134,
            250,
            201,
            164,
            89,
            216,
            202,
            220,
            50,
            221,
            152,
            140,
            33,
            235,
            214
        ],
        "zm": [
            120,
            50,
            98,
            101,
            99,
            98,
            119,
            100,
            103,
            107,
            99,
            119,
            97,
            99,
            110,
            111
        ]
    }
}
window.name = ""
window.alert = function () {}
Math.random = function () {
    return 0.1
}
CanvasRenderingContext2D ={
    toString:function (){
        return '[object CanvasRenderingContext2D]'
    }
}
canvas = {
    getContext:function (){
        return CanvasRenderingContext2D
    }
}
document = {
    toString: function () {
        return '[object HTMLDocument]'
    },
    createElement: function (res) {
        console.log("res::", res)
        return canvas
    },
    getElementById: function () {
        return {}
    },
    getElementsByClassName: function () {
        return {}
    }
}
navigator = {
    userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36',
    toString: function () {
        return '[object Navigator]'
    },
    webdriver: false
}
location = {
    toString: function () {
        return "https://www.zhihu.com/"
    },
    href: "https://www.zhihu.com/"
}
screen = {
    toString: function () {
        return '[object Screen]'
    }
}
history = {
    toString: function () {
        return '[object History]'
    }
}


// ============================ 代理 ============================
function SetProxy(proxyObjs) {
    for (let i = 0; i < proxyObjs.length; i++) {
        const handler = `{
          get: function(target, property, receiver) {
            if (property!=="webpackChunkheifetz" && property!=="__ZH__"){
            console.log("方法:", "get  ", "对象:", "${proxyObjs[i]}", "  属性:", property, "  属性类型：", typeof property, ", 属性值：", target[property])};
            return target[property];
          }
        }`;
        eval(`try {
            ${proxyObjs[i]};
            ${proxyObjs[i]} = new Proxy(${proxyObjs[i]}, ${handler});
        } catch (e) {
            ${proxyObjs[i]} = {};
            ${proxyObjs[i]} = new Proxy(${proxyObjs[i]}, ${handler});
        }`);
    }
}

// SetProxy(["window", "document", "navigator", "location", "screen", "history","canvas","CanvasRenderingContext2D"])

